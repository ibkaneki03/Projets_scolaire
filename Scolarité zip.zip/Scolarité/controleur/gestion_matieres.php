<h2> Gestion des matières </h2>
<?php
    require_once ("vue/vue_insert_matiere.php");

?>