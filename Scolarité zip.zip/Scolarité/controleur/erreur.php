<h2>PAGE INTROUVABLE</h2>
<br>
<br>
<br>

<img src="images/erreur.jpg" width="400px" height="400px">

<a href="index.php?page=1">Revenir à l'accueil</a>