<h3> Ajout d'une matière </h3>

<form method="post">
    <table border="0">
        <tr>
            <td> Nom : </td>
            <td> <input type="text" name="nom"> </td>
        </tr>
        <tr>
            <td> Coefficient : </td>
            <td> <input type="text" name="coeff"> </td>
        </tr>        
        <tr>
            <td> Nombre d'heures : </td>
            <td> <input type="text" name="diplome"> </td>
        </tr>
        <tr>
            <td> La classe : </td>
            <td> <input type="text" name="diplome"> </td>
        </tr>
        <tr>
            <td> Le professeur : </td>
            <td> <input type="text" name="diplome"> </td>
        </tr>
        <tr>
            <td> <input type="submit" name="Annuler" value="Annuler"> </td>
            <td> <input type="submit" name="Valider" value="Valider"> </td>
        </tr>
    </table>
</form>