<h3> Ajout d'un étudiant </h3>

<form method="post">
    <table border="0">
        <tr>
            <td> Nom : </td>
            <td> <input type="text" name="nom"> </td>
        </tr>
        <tr>
            <td> Prénom : </td>
            <td> <input type="text" name="prenom"> </td>
        </tr>        
        <tr>
            <td> Email : </td>
            <td> <input type="text" name="email"> </td>
        </tr>
        <tr>
            <td> Téléphone : </td>
            <td> <input type="text" name="telephone"> </td>
        </tr>
        <tr>
            <td> Adresse : </td>
            <td> <input type="text" name="adresse"> </td>
        </tr>
        <tr>
            <td> La classe : </td>
            <td> <input type="text" name="classe"> </td>
        </tr>
        <tr>
            <td> <input type="submit" name="Annuler" value="Annuler"> </td>
            <td> <input type="submit" name="Valider" value="Valider"> </td>
        </tr>
    </table>
</form>