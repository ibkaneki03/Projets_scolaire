<div class="container text-center mt-5">
  <h1 class="display-5 fw-bold text-primary">Bienvenue sur la gestion de l'Auto-École 🚗</h1>
  <p class="lead">Utilisez le menu ci-dessus pour gérer les candidats, moniteurs, véhicules et cours.</p>
</div>
