<div class="alert alert-danger text-center mt-5">
  <h4>❌ Erreur 404</h4>
  <p>La page demandée est introuvable.</p>
</div>
