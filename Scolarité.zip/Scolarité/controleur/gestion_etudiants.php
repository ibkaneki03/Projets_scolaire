<h2> Gestion des étudiants </h2>
<?php
    require_once ("vue/vue_insert_etudiant.php");

?>